﻿ var clientX=0;clientY=0;
 var clientword=null;
 
function selectionOnClick(info, tab) { 
console.log("selectionOnClick");
window.open("mdict.html?word="+encodeURIComponent(info.selectionText), "window", "width=600,height=400,titlebar=no,directories=no,location=yes, status=no,scrollbars=yes, resizable=yes,top="+clientY+",left="+clientX); 
 
} ;
 
  
var selection = chrome.contextMenus.create({"title": "翻译","contexts":["selection"],"onclick":selectionOnClick}); 
chrome.extension.onRequest.addListener(function(request, sender, sendResponse) {
  if (request.action == "word") {
    if (request.word&&request.word != "") {
	   
		window.open("mdict.html?word="+encodeURIComponent(request.word), "window", "width=600,height=400,titlebar=no,directories=no,location=yes, status=no,scrollbars=yes, resizable=yes,top="+clientY+",left="+clientX); 
		}
  }
  else if(request.action=="changemenu")
  {
	   if (request.word&&request.word != "") {
		 chrome.contextMenus.removeAll();
		 var selection = chrome.contextMenus.create({"title": "翻译 "+request.word,"contexts":["selection"],"onclick":selectionOnClick}); 
    }
  }
  else if (request.action == "location") {
    clientX=request.x;
	clientY=request.y;
  }
});
 

