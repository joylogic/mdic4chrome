﻿ function setChildTextNode(elementId, text) {
    document.getElementById(elementId).innerText = text;
};

function getUrlID(tab) {
	setChildTextNode('title',tab.title);
	 var qrcode = new QRCode(document.getElementById("qrcode"), {
            width : 96,//设置宽高
            height : 96
        });
        qrcode.makeCode(tab.url); 

 var joy = new QRCode(document.getElementById("joylogic"), {
            width : 96,//设置宽高
            height : 96
        });
        joy.makeCode("http://www.joylogic.com"); 
};
 
window.onload=function(){  
 chrome.tabs.getSelected(null,getUrlID);
 };

