﻿
document.addEventListener("dblclick", on_mouse_dbclick, true);
document.addEventListener("mouseup", on_mouse_up, true);
 
 
function oncallback(){ }
function on_mouse_up(event) 
{
	 chrome.extension.sendRequest({action:"location",x: event.screenX,y:event.screenY}, oncallback);
	   var sText = document.selection == undefined ? document.getSelection().toString():document.selection.createRange().text;
    if (event.button==0&&sText != "")
    {
        // todo: 字符串过长的问题.
        if (sText.length > 100)
            sText = sText.substr(0, 100);  
	   chrome.extension.sendRequest({action:"changemenu",word:sText}, oncallback);
    }
}
function on_mouse_dbclick(event) { 
    var sText = document.selection == undefined ? document.getSelection().toString():document.selection.createRange().text;
    if (sText != "")
    {
        // todo: 字符串过长的问题.
        if (sText.length > 100)
            sText = sText.substr(0, 100); 
	   chrome.extension.sendRequest({action:"word",word:sText}, oncallback);
    }
}
